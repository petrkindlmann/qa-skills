import test from 'node:test';
import assert from 'node:assert/strict';
import {quote} from './quote.mjs';
test('standard shipping below threshold',()=>assert.deepEqual(quote(4999),{subtotal:4999,shipping:500,total:5499}));
test('standard shipping above threshold',()=>assert.deepEqual(quote(5001),{subtotal:5001,shipping:0,total:5001}));
test('express cost',()=>assert.deepEqual(quote(6000,'express'),{subtotal:6000,shipping:1200,total:7200}));
